./objects/bmp280.o: bmp280.c bmp280.h drivers\i2c.h
